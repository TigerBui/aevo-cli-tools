#!/usr/bin/env bash
# Antigravity CLI - Unified Cloud Server Management Tool
# Version: 1.0.0
# License: MIT

set -euo pipefail

# --- Configuration & Colors ---
MODULES_DIR="modules"
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# --- UI Helpers ---
print_header() {
    clear
    echo -e "${CYAN}${BOLD}============================================================${NC}"
    echo -e "${CYAN}${BOLD}       🚀 ANTIGRAVITY - CLOUD SERVER MANAGEMENT CLI        ${NC}"
    echo -e "${CYAN}${BOLD}============================================================${NC}"
    echo ""
}

print_error() {
    echo -e "${RED}✗ Error: $1${NC}"
}

print_info() {
    echo -e "${BLUE}i $1${NC}"
}

# --- Module Management ---
list_modules() {
    local count=0
    echo -e "${YELLOW}${BOLD}Danh sách Module có sẵn:${NC}"
    echo -e "------------------------------------------------------------"
    
    # Store modules in an array for easy access
    MODULE_PATHS=()
    while IFS= read -r module; do
        count=$((count + 1))
        local title=$(grep -m 1 "^# TITLE:" "$module" | cut -d ':' -f 2- | xargs || echo "$(basename "$module")")
        local desc=$(grep -m 1 "^# DESC:" "$module" | cut -d ':' -f 2- | xargs || echo "No description")
        
        echo -e "${GREEN}${count}.${NC} ${BOLD}${title}${NC}"
        echo -e "   ${desc}"
        MODULE_PATHS+=("$module")
    done < <(find "$MODULES_DIR" -maxdepth 1 -name "*.sh" | sort)
    
    echo -e "------------------------------------------------------------"
    echo -e "${GREEN}0.${NC} Thoát"
    echo ""
}

run_module() {
    local module_script=$1
    if [[ -f "$module_script" ]]; then
        echo -e "${YELLOW}>>> Đang chạy module: ${BOLD}$(basename "$module_script")${NC}"
        echo -e "${BLUE}------------------------------------------------------------${NC}"
        # Source the module and call 'run' if it exists, otherwise just execute
        if grep -q "run()" "$module_script"; then
            source "$module_script"
            run
        else
            bash "$module_script"
        fi
        echo -e "${BLUE}------------------------------------------------------------${NC}"
        echo -e "${GREEN}✅ Hoàn tất module.${NC}"
        read -p "Nhấn Enter để tiếp tục..."
    else
        print_error "Không tìm thấy file module: $module_script"
    fi
}

# --- Main Logic ---
check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_error "Vui lòng chạy với quyền sudo hoặc root."
        exit 1
    fi
}

interactive_menu() {
    while true; do
        print_header
        list_modules
        
        read -p "Chọn module để thực thi (0-${#MODULE_PATHS[@]}): " choice
        
        if [[ "$choice" == "0" ]]; then
            echo -e "${YELLOW}Tạm biệt!${NC}"
            exit 0
        fi
        
        if [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -le "${#MODULE_PATHS[@]}" ]; then
            local selected_module="${MODULE_PATHS[$((choice-1))]}"
            run_module "$selected_module"
        else
            echo -e "${RED}Lựa chọn không hợp lệ. Vui lòng thử lại.${NC}"
            sleep 1
        fi
    done
}

# START
if [[ $# -gt 0 ]]; then
    # Direct execution mode
    check_root
    run_module "$1"
else
    # Interactive mode
    check_root
    interactive_menu
fi
