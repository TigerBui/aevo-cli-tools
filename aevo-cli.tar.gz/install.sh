#!/usr/bin/env bash
# Aevo CLI Installer - Makes the CLI available globally
set -euo pipefail

INSTALL_DIR="/usr/local/bin"
COMMAND_NAME="aevo"
SCRIPT_PATH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/antigravity.sh"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${GREEN}🚀 Đang cài đặt Aevo CLI toàn cục...${NC}"

if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}✗ Vui lòng chạy với quyền sudo hoặc root.${NC}"
   exit 1
fi

# Cấp quyền thực thi
chmod +x "$SCRIPT_PATH"

# Tạo symbolic link
echo -e "${YELLOW}→ Tạo link: $INSTALL_DIR/$COMMAND_NAME -> $SCRIPT_PATH${NC}"
ln -sf "$SCRIPT_PATH" "$INSTALL_DIR/$COMMAND_NAME"

echo -e "${GREEN}✅ Cài đặt hoàn tất!${NC}"
echo -e "Bây giờ bạn có thể gõ ${BOLD}'aevo'${NC} từ bất kỳ đâu để khởi động CLI."
